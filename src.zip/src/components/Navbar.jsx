import CardNav from './bits/CardNav'
import logo from '/logo.png'

export default function Navbar() {
  const items = [
    { label: "About",    bgColor: "#0D0716", textColor: "#fff", links: [
      { label: "Company", ariaLabel: "About Company", href: "/about" },
      { label: "Careers", ariaLabel: "About Careers", href: "/careers" }
    ]},
    { label: "Projects", bgColor: "#0D0716", textColor: "#fff", links: [
      { label: "Automation", ariaLabel: "Automation Projects", href: "/projects#automation" },
      { label: "Vision",     ariaLabel: "Vision Projects",     href: "/projects#vision" }
    ]},
    { label: "Services", bgColor: "#0D0716", textColor: "#fff", links: [
      { label: "Robotics", ariaLabel: "Robotics Services", href: "/services#robotics" },
      { label: "Testing",  ariaLabel: "Testing Services",  href: "/services#testing" }
    ]},
    { label: "Contact",  bgColor: "#0D0716", textColor: "#fff", links: [
      { label: "Email",    ariaLabel: "Email",    href: "/contact" },
      { label: "Schedule", ariaLabel: "Schedule", href: "/contact#schedule" }
    ]}
  ]

  return (
    <header className="site-header sticky-header norwest-nav">
      <CardNav
        logo={logo}
        logoAlt="Norwest DS"
        items={items}

        /* Colores Norwest */
        baseColor="#EAF6FB"           // texto/link base claro
        menuColor="var(--brand)"      // paneles/menus
        buttonBgColor="var(--brand)"  // botones
        buttonTextColor="#ffffff"     // texto de botón
        ease="power3.out"
      />
    </header>
  )
}