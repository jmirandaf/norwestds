import useMeta from '../hooks/useMeta'

export default function Projects() {
  useMeta({
    title: "Proyectos | Norwest DS",
    description: "Casos reales de integración y automatización.",
    url: "https://norwestds.com/projects"
  })

  return (
    <section className="container pad">
      <h1>Proyectos</h1>
      <p>Próximamente: galería de casos con descripciones técnicas.</p>
    </section>
  )
}