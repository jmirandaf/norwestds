import useMeta from '../hooks/useMeta'

export default function About() {
  useMeta({
    title: "Nosotros | Norwest DS",
    description: "Equipo multidisciplinario con enfoque en resultados.",
    url: "https://norwestds.com/about"
  })

  return (
    <section className="container pad">
      <h1>Nosotros</h1>
      <p>Somos un equipo de ingeniería con experiencia en integración de sistemas y automatización industrial.</p>
    </section>
  )
}