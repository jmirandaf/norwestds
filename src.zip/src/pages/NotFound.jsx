export default function NotFound() {
  return (
    <section style={{padding:24}}>
      <h1>404</h1>
      <p>Página no encontrada.</p>
      <a href="/">Volver al inicio</a>
    </section>
  );
}