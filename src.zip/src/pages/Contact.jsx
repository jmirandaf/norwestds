import useMeta from '../hooks/useMeta'

export default function Contact() {
  useMeta({
    title: "Contacto | Norwest DS",
    description: "Cuéntanos tu reto y lo convertimos en solución.",
    url: "https://norwestds.com/contact"
  })

  return (
    <section className="container pad">
      <h1>Contacto</h1>
      <form
        className="form"
        onSubmit={(e)=>{e.preventDefault(); alert('Conecta EmailJS o tu backend antes de enviar.')}}>
        <input placeholder="Nombre" required />
        <input type="email" placeholder="Email" required />
        <textarea rows="5" placeholder="Mensaje" required />
        <button className="btn" type="submit">Enviar</button>
      </form>
      <p style={{marginTop:12}}>Para envío real, integra EmailJS o un endpoint propio.</p>
    </section>
  )
}